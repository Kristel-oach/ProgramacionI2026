﻿using System;
using System.Collections;

class Program
{
    static void Main(string[] args)
    {
        ArrayList tareas = new ArrayList();
        int opcion;

        do
        {
            Console.WriteLine("\nMENU");
            Console.WriteLine("1. Mostrar tareas");
            Console.WriteLine("2. Agregar tarea");
            Console.WriteLine("3. Eliminar tarea");
            Console.WriteLine("4. Salir");
            Console.Write("Opcion: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("TAREAS:");
                    for (int i = 0; i < tareas.Count; i++)
                    {
                        Console.WriteLine(i + ". " + tareas[i]);
                    }
                    break;

                case 2:
                    Console.Write("Ingrese nueva tarea: ");
                    string tarea = Console.ReadLine();
                    tareas.Add(tarea);
                    break;

                case 3:
                    Console.Write("Ingrese índice a eliminar: ");
                    int indice = int.Parse(Console.ReadLine());

                    if (indice >= 0 && indice < tareas.Count)
                        tareas.RemoveAt(indice);
                    else
                        Console.WriteLine("Índice inválido");
                    break;
            }

        } while (opcion != 4);
    }
}