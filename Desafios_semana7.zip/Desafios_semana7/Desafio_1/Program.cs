﻿using System;

class Program
{
    static void Main(string[] args)
    {
        char[,] tablero = new char[3, 3]
        {
            { '-', '-', '-' },
            { '-', '-', '-' },
            { '-', '-', '-' }
        };

        char jugador = 'X';

        for (int turno = 0; turno < 9; turno++)
        {
            Console.Clear();
            MostrarTablero(tablero);

            Console.WriteLine("Turno del jugador: " + jugador);
            Console.Write("Fila (0-2): ");
            int fila = int.Parse(Console.ReadLine());

            Console.Write("Columna (0-2): ");
            int columna = int.Parse(Console.ReadLine());

            if (tablero[fila, columna] == '-')
            {
                tablero[fila, columna] = jugador;

                if (HayGanador(tablero, jugador))
                {
                    Console.Clear();
                    MostrarTablero(tablero);
                    Console.WriteLine("Ganó el jugador: " + jugador);
                    return;
                }

                jugador = (jugador == 'X') ? 'O' : 'X';
            }
            else
            {
                Console.WriteLine("Posición ocupada. Presiona una tecla...");
                Console.ReadKey();
                turno--;
            }
        }

        Console.WriteLine("Empate");
    }

    static void MostrarTablero(char[,] t)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.Write(t[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    static bool HayGanador(char[,] t, char j)
    {
        for (int i = 0; i < 3; i++)
        {
            if (t[i, 0] == j && t[i, 1] == j && t[i, 2] == j) return true;
            if (t[0, i] == j && t[1, i] == j && t[2, i] == j) return true;
        }

        if (t[0, 0] == j && t[1, 1] == j && t[2, 2] == j) return true;
        if (t[0, 2] == j && t[1, 1] == j && t[2, 0] == j) return true;

        return false;
    }
}