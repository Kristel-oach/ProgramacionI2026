﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double[,] compras = new double[5, 5]
        {
            {30, 20, 10, 5, 10},
            {220, 300, 90, 30, 170},
            {1400, 340, 80, 180, 100},
            {90, 10, 6, 2, 2},
            {500, 270, 30, 50, 150}
        };

        CalcularDescuentos(compras);
    }

    static void CalcularDescuentos(double[,] datos)
    {
        for (int i = 0; i < datos.GetLength(0); i++)
        {
            double total = 0;

            for (int j = 0; j < datos.GetLength(1); j++)
            {
                total += datos[i, j];
            }

            double descuento = 0;

            if (total >= 100 && total <= 1000)
                descuento = total * 0.10;
            else if (total > 1000)
                descuento = total * 0.20;

            Console.WriteLine("Cliente " + (i + 1));
            Console.WriteLine("Total: " + total);
            Console.WriteLine("Descuento: " + descuento);
            Console.WriteLine("Total a pagar: " + (total - descuento));
            Console.WriteLine("-");
        }
    }
}