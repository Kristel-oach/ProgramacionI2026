﻿using System;

public class Constantes
{
    public static void Ejecutar()
    {
        var numero = 10.20;
        Console.WriteLine(numero);
        numero = 3000;
        Console.WriteLine(numero);

        int numero2 = 150;
        Console.WriteLine("valor de constante:" + numero2);
        numero2 = 80;
        Console.WriteLine(numero2);

        const double PI = 3.1416;
        const string mensaje = "¡Bienvenidos!";

    }
}