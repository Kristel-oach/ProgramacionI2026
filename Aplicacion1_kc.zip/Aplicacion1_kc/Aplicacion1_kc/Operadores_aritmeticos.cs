﻿using System;

public class Operadores_aritmeticos
{
    public static void Ejecutar()
    {
        int valor1 = 90, valor2 = 70;
        var valor3 = 2.3;

        //operador de suma 
        int total = valor1 + valor2;
        Console.WriteLine("Total de la suma:" + total);
        Console.WriteLine(valor1 + valor2 + valor3);

        //resta
        int diferencia = valor1 - valor2;
        Console.WriteLine("Total de la resta:" + diferencia);

        //multiplicacion
        var producto = valor3 * valor2;
        Console.WriteLine("Producto" + producto);

        //division
        var resultado = valor1 / valor3;
        Console.WriteLine("resultado:" + resultado);

        //residuo
        var modulo = valor2 % valor3;
        Console.WriteLine("Residuo:" + modulo);
    }
}