﻿using System;

public class Proyecto
{
    public static void Ejecutar()
    {
        Console.WriteLine(45);
        Console.WriteLine("Informaticonfing");
        Console.WriteLine(50 + 60);
    }
}
