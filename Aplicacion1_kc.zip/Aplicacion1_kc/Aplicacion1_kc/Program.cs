﻿
using System;
class Program
{
    static void Main(string[] args)
    {
        Proyecto.Ejecutar();
        Tipos_de_datos.Ejecutar();
        Variables.Ejecutar();
        Concatenacion.Ejecutar();
        Comentarios.Ejecutar();
        Constantes.Ejecutar();
        Casting.Ejecutar();
        Operadores_aritmeticos.Ejecutar();
    }
}
