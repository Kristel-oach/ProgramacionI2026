﻿using System;

public class Tipos_de_datos
{
    public static void Ejecutar()
    {
        int = 1 25 355 456 77888
        
        double = 3.14  4,566

        bool = true / false

        char = 'A'(2)

        float = 1.50f

        string = 'asdasdasdasdas'  'asda sda asd ada'

    }
}