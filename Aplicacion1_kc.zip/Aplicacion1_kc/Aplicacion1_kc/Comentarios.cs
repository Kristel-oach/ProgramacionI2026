﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Comentarios
{
    public static void Ejecutar()
    {
        //uso de la concatenacion en C#
        //Cambios hechos el 20 de febrero 2026

        /*string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad " + edad);

        string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad " + edad);

        string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad " + edad);

        string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad " + edad);

        string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad " + edad);*/

        Console.WriteLine($"Nombre usuario: {nombre}, edad: {edad}");
        Console.WriteLine($"Nombre usuario: {nombre}, edad: {edad}");
        Console.WriteLine($"Nombre usuario: {nombre}, edad: {edad}");
        Console.WriteLine($"Nombre usuario: {nombre}, edad: {edad}");
        Console.WriteLine($"Nombre usuario: {nombre}, edad: {edad}");

    }
}