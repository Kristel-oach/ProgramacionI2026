﻿using System;

public class Concatenacion
{
    public static void Ejecutar()
    {
        string nombre = "Ana";
        int edad = 30;
        Console.WriteLine("Nombre de usuario:" + nombre);
        Console.WriteLine("Edad" + edad);

        Console.WriteLine($"Nombre usuario: {nombre}, edad en 10 años: {edad + 5}");
        Console.ReadKey();

    }
}