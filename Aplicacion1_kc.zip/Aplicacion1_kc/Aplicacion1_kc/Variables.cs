﻿using System;

public class Variables
{
    public static void Ejecutar()
    {
        string minombre = "informaticonfing";
        int edad = 20;
        bool Activo = false;
        DateTime fecha = DateTime.Now;
        float precio = 1.500f;
        decimal descuento = 10.50m;
        double descuento_2 = 10.50;

        Console.WriteLine(minombre);
        Console.WriteLine(edad);
        Console.WriteLine(fecha);
        Console.WriteLine(descuento);
        Console.WriteLine(precio);
        Console.WriteLine(descuento_2);

        Console.ReadKey();


    }
}