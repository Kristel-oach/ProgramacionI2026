﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ingrese un número entero positivo:");
        int num = int.Parse(Console.ReadLine());

        for (int i = 1; i <= num; i++)
        {
            if (i % 2 != 0)
            {
                continue;
            }

            Console.WriteLine(i);
        }
    }
}