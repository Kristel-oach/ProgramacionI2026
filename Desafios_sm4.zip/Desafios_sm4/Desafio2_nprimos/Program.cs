﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ingrese un número entero positivo:");
        int num = int.Parse(Console.ReadLine());

        bool esPrimo = true;

        for (int i = 2; i < num; i++)
        {
            if (num % i == 0)
            {
                esPrimo = false;
                break;
            }
        }

        if (esPrimo && num > 1)
        {
            Console.WriteLine("El número es primo.");
        }
        else
        {
            Console.WriteLine("El número no es primo.");
        }
    }
}