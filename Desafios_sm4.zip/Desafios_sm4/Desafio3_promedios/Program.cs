﻿using System;

class Program
{
    static void Main()
    {
        int suma = 0;
        int cantidad = 0;

        Console.WriteLine("Ingrese las notas del estudiante (1 a 10). Escriba 'fin' para terminar.");

        while (true)
        {
            string entrada = Console.ReadLine();

            if (entrada.ToLower() == "fin")
            {
                break;
            }

            int nota;

            if (int.TryParse(entrada, out nota))
            {
                if (nota >= 1 && nota <= 10)
                {
                    suma += nota;
                    cantidad++;
                }
                else
                {
                    Console.WriteLine("La nota debe estar entre 1 y 10.");
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Ingrese un número o 'fin'.");
            }
        }

        if (cantidad > 0)
        {
            double promedio = (double)suma / cantidad;
            Console.WriteLine("El promedio del estudiante es: " + promedio);
        }
        else
        {
            Console.WriteLine("No se ingresaron notas.");
        }
    }
}