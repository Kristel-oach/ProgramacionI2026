﻿using CRUDAlumnos;

string connectionString =
    "Server=localhost;Database=escuela;Uid=root;Pwd=;";

BDAlumno bd = new BDAlumno(connectionString);

string opcion;

do
{
    Console.WriteLine("\nCRUD ALUMNOS");
    Console.WriteLine("1. Crear alumno");
    Console.WriteLine("2. Listar alumnos");
    Console.WriteLine("3. Actualizar alumno");
    Console.WriteLine("4. Eliminar alumno");
    Console.WriteLine("5. Salir");
    Console.Write("Opción: ");

    opcion = Console.ReadLine() ?? "";

  
    if (opcion == "1")
    {
        Alumno a = new Alumno();

        Console.Write("Carnet: ");
        a.Carnet = Console.ReadLine() ?? "";

        Console.Write("Nombres: ");
        a.Nombres = Console.ReadLine() ?? "";

        Console.Write("Apellidos: ");
        a.Apellidos = Console.ReadLine() ?? "";

        Console.Write("Teléfono: ");
        a.Telefono = int.Parse(Console.ReadLine() ?? "0");

        Console.Write("DPI: ");
        a.DPI = long.Parse(Console.ReadLine() ?? "0");

        bd.Crear(a);
    }

  
    else if (opcion == "2")
    {
        var lista = bd.Get();

        foreach (var a in lista)
        {
            Console.WriteLine($"{a.Carnet} - {a.Nombres} {a.Apellidos}");
        }
    }

 
    else if (opcion == "3")
    {
        Alumno a = new Alumno();

        Console.Write("Carnet a actualizar: ");
        a.Carnet = Console.ReadLine() ?? "";

        Console.Write("Nuevos nombres: ");
        a.Nombres = Console.ReadLine() ?? "";

        Console.Write("Nuevos apellidos: ");
        a.Apellidos = Console.ReadLine() ?? "";

        Console.Write("Nuevo teléfono: ");
        a.Telefono = int.Parse(Console.ReadLine() ?? "0");

        Console.Write("Nuevo DPI: ");
        a.DPI = long.Parse(Console.ReadLine() ?? "0");

        bd.Actualizar(a);
    }


    else if (opcion == "4")
    {
        Console.Write("Carnet a eliminar: ");
        string c = Console.ReadLine() ?? "";

        bd.Eliminar(c);
    }

} while (opcion != "5");