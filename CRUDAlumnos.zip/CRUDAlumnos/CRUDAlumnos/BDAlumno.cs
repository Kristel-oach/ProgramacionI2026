﻿using Dapper;
using MySql.Data.MySqlClient;

namespace CRUDAlumnos;

public class BDAlumno
{
    private MySqlConnection _connection;

    public BDAlumno(string connectionString)
    {
        _connection = new MySqlConnection(connectionString);
    }

 
    public List<Alumno> Get()
    {
        List<Alumno> lista = new List<Alumno>();

        try
        {
            _connection.Open();

            string sql = "SELECT * FROM Alumno";

            lista = _connection.Query<Alumno>(sql).ToList();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            _connection.Close();
        }

        return lista;
    }

 
    public void Crear(Alumno alumno)
    {
        try
        {
            _connection.Open();

            string sql = @"INSERT INTO Alumno
                           (Carnet, Nombres, Apellidos, Telefono, DPI)
                           VALUES
                           (@Carnet, @Nombres, @Apellidos, @Telefono, @DPI)";

            _connection.Execute(sql, alumno);

            Console.WriteLine("Alumno creado correctamente");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            _connection.Close();
        }
    }

    public void Actualizar(Alumno alumno)
    {
        try
        {
            _connection.Open();

            string sql = @"UPDATE Alumno
                           SET Nombres=@Nombres,
                               Apellidos=@Apellidos,
                               Telefono=@Telefono,
                               DPI=@DPI
                           WHERE Carnet=@Carnet";

            _connection.Execute(sql, alumno);

            Console.WriteLine("Alumno actualizado");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            _connection.Close();
        }
    }


    public void Eliminar(string carnet)
    {
        try
        {
            _connection.Open();

            string sql = "DELETE FROM Alumno WHERE Carnet=@Carnet";

            _connection.Execute(sql, new { Carnet = carnet });

            Console.WriteLine("Alumno eliminado");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            _connection.Close();
        }
    }
}